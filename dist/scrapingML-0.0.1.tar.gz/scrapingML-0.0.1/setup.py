from setuptools import setup

setup(
    name="scrapingML",
    version="0.0.1",
    author="microlab.ec",
    # author_email="contacto@microlab.ec",
    description="Social scraping library",
    # long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://microlab.ec",
    packages=["C:/Users/Christian/Desktop/scraping_ml","scrapingML"]
)